// services/cgimBasketComexService.ts
import type { NcmSeries, Year } from "../utils/cgimTypes";
import { normalizeNcm } from "../utils/cgimAggregation";
import { fetchComexYearByNcm, type TradeFlow } from "./comexApiService";

export interface BasketProgress {
  total: number;
  done: number;
  current?: { ncm: string; year: number };
  stage?: string;
}

export interface BasketOptions {
  flow: TradeFlow;
  years: Year[];
  concurrency?: number;   // default 4
  useCache?: boolean;     // default true
  cacheTtlHours?: number; // default 72
  onProgress?: (p: BasketProgress) => void;
}

const DEFAULTS = {
  concurrency: 4,
  useCache: true,
  cacheTtlHours: 72,
};

function cacheKey(flow: TradeFlow, ncm: string, year: number) {
  return `cgim:comex:${flow}:${ncm}:${year}`;
}

function nowMs() {
  return Date.now();
}

function getCached(flow: TradeFlow, ncm: string, year: number, ttlHours: number) {
  const k = cacheKey(flow, ncm, year);
  const raw = localStorage.getItem(k);
  if (!raw) return null;
  try {
    const obj = JSON.parse(raw) as { ts: number; fob: number; kg: number };
    if (nowMs() - obj.ts > ttlHours * 3600_000) return null;
    return { fob: obj.fob ?? 0, kg: obj.kg ?? 0 };
  } catch {
    return null;
  }
}

function setCached(flow: TradeFlow, ncm: string, year: number, value: { fob: number; kg: number }) {
  const k = cacheKey(flow, ncm, year);
  try {
    localStorage.setItem(k, JSON.stringify({ ts: nowMs(), ...value }));
  } catch {
    // ignore
  }
}

async function runPool<T, R>(
  items: T[],
  concurrency: number,
  worker: (item: T) => Promise<R>
): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let i = 0;

  const runners = new Array(Math.min(concurrency, items.length)).fill(0).map(async () => {
    while (true) {
      const idx = i++;
      if (idx >= items.length) break;
      results[idx] = await worker(items[idx]);
    }
  });

  await Promise.all(runners);
  return results;
}

export async function fetchBasketAnnualByNcm(
  ncmListRaw: string[],
  options: BasketOptions
): Promise<NcmSeries[]> {
  const cfg = { ...DEFAULTS, ...options };
  const years = cfg.years.map(Number).filter((y) => Number.isFinite(y));

  const normalized = ncmListRaw.map((raw) => ({ raw, ncm: normalizeNcm(raw) }));
  const valid = normalized.filter((x) => x.ncm) as Array<{ raw: string; ncm: string }>;

  const totalTasks = valid.length * years.length;
  let done = 0;

  const progress = (current?: { ncm: string; year: number }, stage?: string) => {
    cfg.onProgress?.({ total: totalTasks, done, current, stage });
  };

  progress(undefined, "init");

  const tasks: Array<{ ncm: string; ncmRaw: string; year: number }> = [];
  for (const item of valid) for (const y of years) tasks.push({ ncm: item.ncm, ncmRaw: item.raw, year: y });

  const taskResults = await runPool(tasks, cfg.concurrency!, async (t) => {
    progress({ ncm: t.ncm, year: t.year }, "fetch");

    if (cfg.useCache) {
      const cached = getCached(cfg.flow, t.ncm, t.year, cfg.cacheTtlHours!);
      if (cached) {
        done++;
        progress({ ncm: t.ncm, year: t.year }, "cache_hit");
        return { ...t, value: cached };
      }
    }

    const value = await fetchComexYearByNcm({ flow: cfg.flow, ncm: t.ncm, year: t.year });

    if (cfg.useCache) setCached(cfg.flow, t.ncm, t.year, value);

    done++;
    progress({ ncm: t.ncm, year: t.year }, "fetched");

    return { ...t, value };
  });

  const byNcm = new Map<string, NcmSeries>();

  for (const r of taskResults) {
    if (!byNcm.has(r.ncm)) {
      byNcm.set(r.ncm, { ncmRaw: r.ncmRaw, ncm: r.ncm, years: {} });
    }
    byNcm.get(r.ncm)!.years[String(r.year)] = { fob: r.value.fob ?? 0, kg: r.value.kg ?? 0 };
  }

  progress(undefined, "done");
  return Array.from(byNcm.values());
}
