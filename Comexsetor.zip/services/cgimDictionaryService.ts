// services/cgimDictionaryService.ts
import * as XLSX from "xlsx";
import type { DictionaryRow } from "../utils/cgimTypes";
import { normalizeNcm } from "../utils/cgimAggregation";

export interface LoadDictionaryFromPublicOptions {
  publicPath?: string; // default: "/dictionaries/cgim_dinti.xlsx"
  sheetName?: string;  // se não vier, usa primeira aba
  cacheKey?: string;   // cache do parse
}

function normHeader(s: unknown): string {
  return String(s ?? "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function detectHeaderRow(rows: any[][]): number {
  for (let i = 0; i < Math.min(rows.length, 25); i++) {
    const line = rows[i] ?? [];
    const hasNcm = line.some((cell) => normHeader(cell).includes("ncm"));
    if (hasNcm) return i;
  }
  return 0;
}

function guessHeaderMap(rows: any[][], headerRowIdx: number) {
  const header = rows[headerRowIdx] ?? [];
  const norm = header.map(normHeader);

  const findIdx = (pred: (h: string) => boolean): number | null => {
    const i = norm.findIndex(pred);
    return i >= 0 ? i : null;
  };

  const ncmCol =
    findIdx((h) => h === "ncm" || h.includes("codigo ncm") || h.includes("cod ncm")) ??
    findIdx((h) => h.includes("ncm")) ??
    null;

  if (ncmCol === null) {
    throw new Error(`cgimDictionaryService: não consegui identificar a coluna de NCM no header.`);
  }

  const categoriaCol =
    findIdx((h) => h === "categoria" || h.includes("categoria ")) ??
    findIdx((h) => h.includes("cat")) ??
    null;

  const subcategoriaCol =
    findIdx((h) => h === "subcategoria" || h.includes("sub categoria") || h.includes("sub-categoria")) ??
    findIdx((h) => h.includes("subcat")) ??
    null;

  return { ncmCol, categoriaCol, subcategoriaCol, headerRowIdx };
}

export async function loadCgimDictionaryFromPublic(
  options: LoadDictionaryFromPublicOptions = {}
): Promise<DictionaryRow[]> {
  const publicPath = options.publicPath ?? "/dictionaries/cgim_dinti.xlsx";
  const cacheKey = options.cacheKey ?? "cgim:dictionary:parsed:public";

  const cached = localStorage.getItem(cacheKey);
  if (cached) {
    try {
      const parsed = JSON.parse(cached) as DictionaryRow[];
      if (Array.isArray(parsed) && parsed.length) return parsed;
    } catch {
      // ignore
    }
  }

  const res = await fetch(publicPath);
  if (!res.ok) throw new Error(`Falha ao carregar dicionário em ${publicPath} (HTTP ${res.status}).`);
  const arrayBuffer = await res.arrayBuffer();

  const wb = XLSX.read(arrayBuffer, { type: "array" });
  const sheetName = options.sheetName ?? wb.SheetNames[0];
  const ws = wb.Sheets[sheetName];
  if (!ws) throw new Error(`Aba "${sheetName}" não encontrada em ${publicPath}.`);

  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true }) as any[][];
  if (!rows.length) return [];

  const headerRowIdx = detectHeaderRow(rows);
  const map = guessHeaderMap(rows, headerRowIdx);

  const out: DictionaryRow[] = [];

  for (let r = map.headerRowIdx + 1; r < rows.length; r++) {
    const line = rows[r] ?? [];
    const ncmRaw = String(line[map.ncmCol] ?? "").trim();
    const ncm = normalizeNcm(ncmRaw);

    const categoria =
      map.categoriaCol !== null ? String(line[map.categoriaCol] ?? "").trim() : "";
    const subcategoria =
      map.subcategoriaCol !== null ? String(line[map.subcategoriaCol] ?? "").trim() : "";

    if (!ncmRaw && !categoria && !subcategoria) continue;

    out.push({
      ncmRaw,
      ncm,
      categoria: categoria || null,
      subcategoria: subcategoria || null,
      source: {
        fileName: publicPath,
        sheetName,
        rowNumber: r + 1,
      },
    });
  }

  try {
    localStorage.setItem(cacheKey, JSON.stringify(out));
  } catch {
    // ignore
  }

  return out;
}
