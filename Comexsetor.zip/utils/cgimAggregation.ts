// utils/cgimAggregation.ts
import type {
  AggregateNodeTotals,
  AggregateOptions,
  CgimAggregate,
  CgimDiagnostics,
  DictionaryRow,
  NcmSeries,
  NcmYearValue,
} from "./cgimTypes";

const DEFAULT_LABELS = {
  unmappedCategory: "Sem categoria (não mapeado)",
  incompleteMappedCategory: "Sem categoria (mapeamento incompleto)",
  noSubcategory: "Sem subcategoria",
};

const NO_SUBCATEGORY_KEY = "__NO_SUBCATEGORY__";

export function normalizeNcm(raw: unknown): string | null {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  if (!s) return null;

  // remove tudo que não é dígito
  const digits = s.replace(/\D/g, "");

  // NCM canônica: 8 dígitos
  if (digits.length !== 8) return null;

  return digits;
}

function safeLabel(v: string | null | undefined): string {
  const s = (v ?? "").trim();
  return s.length ? s : "";
}

export function buildDictionaryIndex(rows: DictionaryRow[]) {
  const index = new Map<
    string,
    { ncm: string; categoria: string | null; subcategoria: string | null; sources: any[] }
  >();

  let totalRows = rows.length;
  let validNcmRows = 0;
  let invalidNcmRows = 0;

  const seenMappings: Map<string, Set<string>> = new Map();
  let duplicatesSameMapping = 0;
  let conflictsDifferentMapping = 0;
  const conflicts: CgimDiagnostics["dictionary"]["conflicts"] = [];

  for (const r of rows) {
    const ncm = r.ncm ?? normalizeNcm(r.ncmRaw);
    if (!ncm) {
      invalidNcmRows++;
      continue;
    }
    validNcmRows++;

    const categoria = safeLabel(r.categoria) || null;
    const subcategoria = safeLabel(r.subcategoria) || null;

    const mappingSignature = JSON.stringify({ categoria, subcategoria });

    if (!seenMappings.has(ncm)) seenMappings.set(ncm, new Set());
    const set = seenMappings.get(ncm)!;

    if (set.has(mappingSignature)) {
      duplicatesSameMapping++;
    } else if (set.size > 0) {
      conflictsDifferentMapping++;
    }
    set.add(mappingSignature);

    const existing = index.get(ncm);
    const sourceWithRaw = { ...(r.source ?? {}), ncmRaw: r.ncmRaw };

    if (!existing) {
      index.set(ncm, {
        ncm,
        categoria,
        subcategoria,
        sources: [sourceWithRaw],
      });
    } else {
      existing.sources.push(sourceWithRaw);
      // mantém o primeiro como canônico; conflitos ficam em diagnostics
    }
  }

  for (const [ncm, sigs] of seenMappings.entries()) {
    if (sigs.size > 1) {
      const mappings = Array.from(sigs).map((sig) => JSON.parse(sig));
      conflicts.push({ ncm, mappings });
    }
  }

  const diagnostics: CgimDiagnostics["dictionary"] = {
    totalRows,
    validNcmRows,
    invalidNcmRows,
    distinctNcms: index.size,
    duplicatesSameMapping,
    conflictsDifferentMapping,
    conflicts,
  };

  return { index, diagnostics };
}

function sumTotals(a: AggregateNodeTotals, b: AggregateNodeTotals) {
  a.fob += b.fob;
  a.kg += b.kg;
}

function addYearTotals(
  yearsAgg: Record<string, NcmYearValue>,
  yearsAdd: Record<string, NcmYearValue>
) {
  for (const [y, v] of Object.entries(yearsAdd)) {
    if (!yearsAgg[y]) yearsAgg[y] = { fob: 0, kg: 0 };
    yearsAgg[y].fob += v.fob;
    yearsAgg[y].kg += v.kg;
  }
}

function seriesTotal(series: NcmSeries): AggregateNodeTotals {
  let fob = 0;
  let kg = 0;
  for (const v of Object.values(series.years)) {
    fob += Number(v.fob) || 0;
    kg += Number(v.kg) || 0;
  }
  return { fob, kg };
}

function isAllZero(series: NcmSeries, targetYears?: number[]): boolean {
  const years = targetYears?.length ? targetYears.map(String) : Object.keys(series.years);
  if (years.length === 0) return true;

  for (const y of years) {
    const v = series.years[y];
    const fob = Number(v?.fob) || 0;
    const kg = Number(v?.kg) || 0;
    if (fob !== 0 || kg !== 0) return false;
  }
  return true;
}

export function aggregateCgim(
  dictionaryRows: DictionaryRow[],
  seriesList: NcmSeries[],
  options: AggregateOptions = {}
): CgimAggregate {
  const labels = { ...DEFAULT_LABELS, ...(options.labels ?? {}) };
  const { index: dictIndex, diagnostics: dictDiag } = buildDictionaryIndex(dictionaryRows);

  const aggregate: CgimAggregate = {
    totals: { fob: 0, kg: 0 },
    years: {},
    categorias: {},
    diagnostics: {
      dictionary: dictDiag,
      aggregation: {
        inputSeries: seriesList.length,
        invalidNcmSeries: 0,
        excludedAllZeroSeries: 0,
        includedSeries: 0,
        unmappedNcms: [],
        mappedButMissingCategory: [],
      },
    },
  };

  const unmappedAccumulator: Map<string, AggregateNodeTotals> = new Map();
  const mappedMissingCategory: Map<string, { subcategoria: string | null }> = new Map();

  for (const series of seriesList) {
    const ncm = series.ncm ?? normalizeNcm(series.ncmRaw ?? "");
    if (!ncm) {
      aggregate.diagnostics.aggregation.invalidNcmSeries++;
      continue;
    }

    const allZero = isAllZero(series, options.targetYears);
    if (allZero && !options.includeAllZeroSeries) {
      aggregate.diagnostics.aggregation.excludedAllZeroSeries++;
      continue;
    }

    aggregate.diagnostics.aggregation.includedSeries++;

    const totals = seriesTotal(series);
    const dict = dictIndex.get(ncm);

    let categoriaLabel: string;
    let categoriaKey: string;
    let subcatLabel: string;
    let subcatKey: string;
    let isMapped: boolean;

    if (!dict) {
      isMapped = false;
      categoriaLabel = labels.unmappedCategory;
      categoriaKey = "__UNMAPPED__";
      subcatLabel = labels.noSubcategory;
      subcatKey = NO_SUBCATEGORY_KEY;

      const prev = unmappedAccumulator.get(ncm) ?? { fob: 0, kg: 0 };
      prev.fob += totals.fob;
      prev.kg += totals.kg;
      unmappedAccumulator.set(ncm, prev);
    } else {
      isMapped = true;

      if (!dict.categoria || !dict.categoria.trim()) {
        categoriaLabel = labels.incompleteMappedCategory;
        categoriaKey = "__MAPPED_MISSING_CATEGORY__";
        mappedMissingCategory.set(ncm, { subcategoria: dict.subcategoria ?? null });
      } else {
        categoriaLabel = dict.categoria.trim();
        categoriaKey = slugKey(categoriaLabel);
      }

      if (!dict.subcategoria || !dict.subcategoria.trim()) {
        subcatLabel = labels.noSubcategory;
        subcatKey = NO_SUBCATEGORY_KEY;
      } else {
        subcatLabel = dict.subcategoria.trim();
        subcatKey = slugKey(subcatLabel);
      }
    }

    if (!aggregate.categorias[categoriaKey]) {
      aggregate.categorias[categoriaKey] = {
        key: categoriaKey,
        label: categoriaLabel,
        fob: 0,
        kg: 0,
        subcategorias: {},
      };
    }
    const catNode = aggregate.categorias[categoriaKey];

    if (!catNode.subcategorias[subcatKey]) {
      catNode.subcategorias[subcatKey] = {
        key: subcatKey,
        label: subcatLabel,
        fob: 0,
        kg: 0,
        ncms: {},
      };
    }
    const subNode = catNode.subcategorias[subcatKey];

    if (!subNode.ncms[ncm]) {
      subNode.ncms[ncm] = {
        ncm,
        fob: 0,
        kg: 0,
        years: {},
        mapping: { categoriaKey, subcategoriaKey: subcatKey, isMapped },
      };
    }
    const ncmNode = subNode.ncms[ncm];

    sumTotals(ncmNode, totals);
    sumTotals(subNode, totals);
    sumTotals(catNode, totals);
    sumTotals(aggregate.totals, totals);

    addYearTotals(ncmNode.years, series.years);
    addYearTotals(aggregate.years, series.years);
  }

  aggregate.diagnostics.aggregation.unmappedNcms = Array.from(unmappedAccumulator.entries())
    .map(([ncm, t]) => ({ ncm, totalFob: t.fob, totalKg: t.kg }))
    .sort((a, b) => b.totalFob - a.totalFob);

  aggregate.diagnostics.aggregation.mappedButMissingCategory = Array.from(mappedMissingCategory.entries()).map(
    ([ncm, v]) => ({ ncm, subcategoria: v.subcategoria })
  );

  if (!options.keepEmptyBuckets) pruneEmptyBuckets(aggregate);

  return aggregate;
}

function pruneEmptyBuckets(agg: CgimAggregate) {
  for (const catKey of Object.keys(agg.categorias)) {
    const cat = agg.categorias[catKey];
    for (const subKey of Object.keys(cat.subcategorias)) {
      const sub = cat.subcategorias[subKey];
      if (Object.keys(sub.ncms).length === 0) delete cat.subcategorias[subKey];
    }
    if (Object.keys(cat.subcategorias).length === 0) delete agg.categorias[catKey];
  }
}

function slugKey(label: string): string {
  return label
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "_")
    .replace(/[^\w_]+/g, "");
}
